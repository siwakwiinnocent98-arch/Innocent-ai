# INNOCENT AI

A starter full-stack AI chat website using Express, the OpenAI Responses API, and Supabase Auth + Postgres.

## Requirements
- Node.js 20+
- An OpenAI API key with API billing enabled
- A Supabase project

## 1. Create the Supabase database
1. Create a project at https://supabase.com.
2. Open **SQL Editor** in the Supabase dashboard.
3. Paste all contents of `supabase.sql` and run it.
4. In **Authentication > Providers > Email**, enable email/password sign-in.
5. For a first test, you may turn email confirmation off in Authentication settings. For a public launch, keep email confirmation on and configure the email provider.

## 2. Configure the website
1. Copy `.env.example` to `.env`.
2. Add your OpenAI API key to `OPENAI_API_KEY`.
3. Add your Supabase project URL and anon/public key to `.env`.
4. Open `public/app.js` and replace:
   - `PASTE_YOUR_SUPABASE_URL_HERE`
   - `PASTE_YOUR_SUPABASE_ANON_KEY_HERE`
   with the same Supabase URL and anon/public key.
5. Never put your OpenAI API key in `public/` or browser JavaScript. Never publish `.env`.

## 3. Run locally
```bash
npm install
npm run dev
```
Open http://localhost:3000.

## 4. Deploy
This project is a Node/Express server, so deploy it to a Node host such as Render or Railway (not a static-only hosting plan).
- Push the project to a private GitHub repository.
- Create a new Web Service on Render and connect the repository.
- Build command: `npm install`
- Start command: `npm start`
- Add environment variables from `.env` in the host dashboard.
- Deploy, then open the public URL.
- Add your final domain to Supabase Authentication > URL Configuration > Site URL and Redirect URLs.

## 5. Important production checks
- Set a spending limit/budget alert in your OpenAI account. API usage can cost money.
- Add rate limiting, CAPTCHA/abuse prevention, logging, and a privacy policy before allowing public sign-ups.
- The starter stores messages under each authenticated user's ID with database Row Level Security. Do not remove those policies.
- This starter does not include web browsing/search tools, file uploads, image generation, voice, or an admin dashboard yet. Research answers are model knowledge, not guaranteed live internet research.
- The history sidebar groups saved messages into conversations and lets the signed-in user reopen them.
- Do not collect unnecessary personal information. Never ask users for passwords, financial credentials, or sensitive data in chat.

## API flow
Browser -> Express `/api/chat` -> OpenAI `POST /v1/responses` -> answer -> browser.
The OpenAI key is only read by the server.
