// Add your Supabase project URL and anon key here. The anon key is designed for browser use;
// database security is enforced by the Row Level Security policies in supabase.sql.
const SUPABASE_URL = "PASTE_YOUR_SUPABASE_URL_HERE";
const SUPABASE_ANON_KEY = "PASTE_YOUR_SUPABASE_ANON_KEY_HERE";
const supabaseReady = SUPABASE_URL.startsWith("https://") && !SUPABASE_URL.includes("PASTE_") && !SUPABASE_ANON_KEY.includes("PASTE_");
const sb = supabaseReady ? window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY) : null;

const $ = (id) => document.getElementById(id);
const authScreen = $("authScreen"), app = $("app");
let authMode = "login";
let conversationId = crypto.randomUUID();
let currentMessages = [];
let sending = false;

function showAuthMessage(message, good = false) {
  $("authMessage").textContent = message;
  $("authMessage").style.color = good ? "#75ddb0" : "#ffbd85";
}
function setAuthMode(mode) {
  authMode = mode;
  $("loginTab").classList.toggle("active", mode === "login");
  $("signupTab").classList.toggle("active", mode === "signup");
  $("nameLabel").classList.toggle("hidden", mode !== "signup");
  $("authSubmit").textContent = mode === "login" ? "Sign in" : "Create account";
  $("passwordInput").autocomplete = mode === "login" ? "current-password" : "new-password";
  showAuthMessage("");
}
$("loginTab").onclick = () => setAuthMode("login");
$("signupTab").onclick = () => setAuthMode("signup");

$("authForm").addEventListener("submit", async (event) => {
  event.preventDefault();
  if (!sb) return showAuthMessage("Set your Supabase URL and anon key in public/app.js first.");
  const email = $("emailInput").value.trim();
  const password = $("passwordInput").value;
  $("authSubmit").disabled = true;
  try {
    if (authMode === "signup") {
      const { data, error } = await sb.auth.signUp({
        email, password,
        options: { data: { full_name: $("nameInput").value.trim() } }
      });
      if (error) throw error;
      if (!data.session) showAuthMessage("Account created. Check your email to confirm, then sign in.", true);
      else await enterApp(data.user);
    } else {
      const { data, error } = await sb.auth.signInWithPassword({ email, password });
      if (error) throw error;
      await enterApp(data.user);
    }
  } catch (error) { showAuthMessage(error.message || "Authentication failed."); }
  finally { $("authSubmit").disabled = false; }
});

async function getToken() {
  const { data } = await sb.auth.getSession();
  return data.session?.access_token;
}
async function api(path, options = {}) {
  const token = await getToken();
  const response = await fetch(path, {
    ...options,
    headers: {
      "Content-Type": "application/json",
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
      ...(options.headers || {})
    }
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.error || "Request failed.");
  return data;
}
async function enterApp(user) {
  authScreen.classList.add("hidden");
  app.classList.remove("hidden");
  $("userEmail").textContent = user.email || "";
  newChat();
  await loadHistory();
}
async function checkSession() {
  if (!sb) return;
  const { data } = await sb.auth.getSession();
  if (data.session?.user) await enterApp(data.session.user);
}
$("logoutBtn").onclick = async () => { await sb?.auth.signOut(); app.classList.add("hidden"); authScreen.classList.remove("hidden"); };
$("newChatBtn").onclick = newChat;
$("menuBtn").onclick = () => $("sidebar")?.classList.toggle("open");
document.querySelector(".sidebar").id = "sidebar";

function newChat() {
  conversationId = crypto.randomUUID();
  currentMessages = [];
  $("chat").innerHTML = "";
  $("chat").classList.add("hidden");
  $("welcome").classList.remove("hidden");
  $("promptInput").value = "";
  $("sidebar").classList.remove("open");
  $("promptInput").focus();
}
function addMessage(role, content) {
  $("welcome").classList.add("hidden");
  $("chat").classList.remove("hidden");
  const row = document.createElement("div");
  row.className = `message ${role}`;
  const avatar = document.createElement("div");
  avatar.className = "avatar";
  avatar.textContent = role === "user" ? "Y" : "IA";
  const body = document.createElement("div");
  body.className = "message-body";
  body.textContent = content;
  row.append(avatar, body);
  $("chat").append(row);
  $("chat").scrollTop = $("chat").scrollHeight;
  return body;
}
function addHistoryItem(title, id) {
  const button = document.createElement("button");
  button.className = "history-item";
  button.textContent = title;
  button.title = title;
  button.onclick = async () => {
    try {
      const result = await api(`/api/history?conversationId=${encodeURIComponent(id)}`);
      conversationId = id;
      currentMessages = result.messages.map(({ role, content }) => ({ role, content }));
      $("chat").innerHTML = "";
      $("welcome").classList.add("hidden");
      $("chat").classList.remove("hidden");
      for (const message of currentMessages) addMessage(message.role, message.content);
      $("sidebar").classList.remove("open");
    } catch (error) { alert(error.message); }
  };
  $("historyList").append(button);
}
async function loadHistory() {
  try {
    const { messages } = await api("/api/history");
    $("historyList").innerHTML = "";
    const conversations = new Map();
    for (const item of messages) {
      if (item.conversation_id && item.role === "user" && !conversations.has(item.conversation_id)) {
        conversations.set(item.conversation_id, item.content.slice(0, 55));
      }
    }
    for (const [id, title] of conversations) addHistoryItem(title, id);
  } catch (error) { console.warn(error.message); }
}

async function sendMessage(text) {
  if (sending || !text.trim()) return;
  sending = true;
  $("sendBtn").disabled = true;
  addMessage("user", text);
  currentMessages.push({ role: "user", content: text });
  const placeholder = addMessage("assistant", "Thinking...");
  try {
    const { answer } = await api("/api/chat", {
      method: "POST",
      body: JSON.stringify({ messages: currentMessages.slice(-20), conversationId })
    });
    placeholder.textContent = answer;
    currentMessages.push({ role: "assistant", content: answer });
    await loadHistory();
  } catch (error) {
    placeholder.textContent = `Sorry, I couldn't answer that. ${error.message}`;
    currentMessages.pop();
  } finally {
    sending = false;
    $("sendBtn").disabled = false;
    $("promptInput").focus();
    $("chat").scrollTop = $("chat").scrollHeight;
  }
}
$("chatForm").addEventListener("submit", (event) => {
  event.preventDefault();
  const value = $("promptInput").value.trim();
  if (!value) return;
  $("promptInput").value = "";
  $("promptInput").style.height = "auto";
  sendMessage(value);
});
$("promptInput").addEventListener("input", (event) => {
  event.target.style.height = "auto";
  event.target.style.height = `${Math.min(event.target.scrollHeight, 160)}px`;
});
$("promptInput").addEventListener("keydown", (event) => {
  if (event.key === "Enter" && !event.shiftKey) {
    event.preventDefault();
    $("chatForm").requestSubmit();
  }
});
document.querySelectorAll(".suggestion").forEach((button) => {
  button.addEventListener("click", () => sendMessage(button.dataset.prompt));
});
$("clearHistoryBtn").onclick = async () => {
  if (!confirm("Delete all saved messages from your account? This cannot be undone.")) return;
  try {
    await api("/api/history", { method: "DELETE" });
    $("historyList").innerHTML = '<p class="tiny">Your saved chats will appear here.</p>';
    newChat();
  } catch (error) { alert(error.message); }
};
checkSession();
