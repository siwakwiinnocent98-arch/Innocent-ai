import express from "express";
import dotenv from "dotenv";
import { createClient } from "@supabase/supabase-js";
import path from "node:path";
import { fileURLToPath } from "node:url";

dotenv.config();

const app = express();
const port = Number(process.env.PORT || 3000);
const __dirname = path.dirname(fileURLToPath(import.meta.url));

app.use(express.json({ limit: "1mb" }));
app.use(express.static(path.join(__dirname, "public")));

const required = ["OPENAI_API_KEY", "SUPABASE_URL", "SUPABASE_ANON_KEY"];
for (const key of required) {
  if (!process.env[key]) console.warn(`Missing environment variable: ${key}`);
}

const supabase = process.env.SUPABASE_URL && process.env.SUPABASE_ANON_KEY
  ? createClient(process.env.SUPABASE_URL, process.env.SUPABASE_ANON_KEY, {
      auth: { persistSession: false, autoRefreshToken: false }
    })
  : null;

function requireConfig(res) {
  if (!process.env.OPENAI_API_KEY) {
    res.status(500).json({ error: "The server is missing OPENAI_API_KEY." });
    return false;
  }
  if (!supabase) {
    res.status(500).json({ error: "The server is missing Supabase configuration." });
    return false;
  }
  return true;
}

async function getUser(req, res) {
  const header = req.headers.authorization || "";
  const token = header.startsWith("Bearer ") ? header.slice(7) : "";
  if (!token) {
    res.status(401).json({ error: "Please sign in first." });
    return null;
  }
  const { data, error } = await supabase.auth.getUser(token);
  if (error || !data.user) {
    res.status(401).json({ error: "Your session has expired. Please sign in again." });
    return null;
  }
  // Use the signed-in user's JWT for database queries so Supabase RLS can
  // evaluate auth.uid() and enforce per-user access.
  const userDb = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_ANON_KEY, {
    global: { headers: { Authorization: `Bearer ${token}` } },
    auth: { persistSession: false, autoRefreshToken: false }
  });
  return { user: data.user, db: userDb };
}

app.get("/api/health", (_req, res) => {
  res.json({ ok: true, app: "INNOCENT AI" });
});

app.post("/api/chat", async (req, res) => {
  if (!requireConfig(res)) return;
  const auth = await getUser(req, res);
  if (!auth) return;
  const { user, db } = auth;

  const { messages, conversationId } = req.body || {};
  if (!Array.isArray(messages) || messages.length === 0 || messages.length > 30) {
    return res.status(400).json({ error: "Send between 1 and 30 recent messages." });
  }

  const safeMessages = messages.map((m) => ({
    role: m?.role === "assistant" ? "assistant" : "user",
    content: String(m?.content || "").slice(0, 12000)
  })).filter((m) => m.content.trim());

  if (!safeMessages.length || safeMessages[safeMessages.length - 1].role !== "user") {
    return res.status(400).json({ error: "Your latest message must be a user message." });
  }

  try {
    const apiResponse = await fetch("https://api.openai.com/v1/responses", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${process.env.OPENAI_API_KEY}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        model: process.env.OPENAI_MODEL || "gpt-4.1-mini",
        instructions: "You are INNOCENT AI, a helpful, accurate, friendly AI assistant. Help with learning, writing, coding, explanations, and research. Be honest about uncertainty. Do not claim to have browsed the web unless a search tool is enabled. For code, provide complete and safe examples.",
        input: safeMessages.map((m) => ({
          role: m.role,
          content: [{ type: "input_text", text: m.content }]
        }))
      })
    });

    const data = await apiResponse.json();
    if (!apiResponse.ok) {
      console.error("OpenAI API error:", data);
      return res.status(apiResponse.status).json({
        error: data?.error?.message || "The AI service could not complete your request."
      });
    }

    const answer = (data.output || [])
      .flatMap((item) => item.content || [])
      .filter((part) => part.type === "output_text")
      .map((part) => part.text)
      .join("\n")
      .trim();

    if (!answer) return res.status(502).json({ error: "The AI returned an empty answer. Please try again." });

    // Save only after successful generation. RLS ensures users can access only their own rows.
    const { error: saveError } = await db.from("messages").insert([
      { user_id: user.id, conversation_id: conversationId || null, role: "user", content: safeMessages[safeMessages.length - 1].content },
      { user_id: user.id, conversation_id: conversationId || null, role: "assistant", content: answer }
    ]);
    if (saveError) console.error("Message save error:", saveError.message);

    res.json({ answer });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Something went wrong while contacting the AI service." });
  }
});

app.get("/api/history", async (req, res) => {
  if (!requireConfig(res)) return;
  const auth = await getUser(req, res);
  if (!auth) return;
  const { user, db } = auth;
  let query = db
    .from("messages")
    .select("id, conversation_id, role, content, created_at")
    .eq("user_id", user.id)
    .order("created_at", { ascending: true })
    .limit(500);
  if (req.query.conversationId) query = query.eq("conversation_id", String(req.query.conversationId));
  const { data, error } = await query;
  if (error) return res.status(500).json({ error: "Could not load chat history." });
  res.json({ messages: data || [] });
});

app.delete("/api/history", async (req, res) => {
  if (!requireConfig(res)) return;
  const auth = await getUser(req, res);
  if (!auth) return;
  const { user, db } = auth;
  const { error } = await db.from("messages").delete().eq("user_id", user.id);
  if (error) return res.status(500).json({ error: "Could not delete chat history." });
  res.json({ ok: true });
});

app.use((req, res, next) => {
  if (req.method !== "GET" || req.path.startsWith("/api/")) return next();
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

app.listen(port, () => console.log(`INNOCENT AI running at http://localhost:${port}`));
