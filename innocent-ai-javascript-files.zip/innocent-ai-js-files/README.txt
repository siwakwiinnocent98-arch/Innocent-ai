INNOCENT AI - JavaScript files

Files:
- server.js: Node.js/Express backend. Keeps OPENAI_API_KEY on the server and exposes /api/chat.
- public/app.js: browser-side JavaScript for login, chat UI, and Supabase integration.

IMPORTANT:
These files are designed to replace the matching files in the INNOCENT AI starter project.
Do not upload a .env file or any secret API key to GitHub.

How to use:
1. Extract this ZIP on your phone/computer.
2. In your INNOCENT AI project, replace the existing server.js with this server.js.
3. Open the public folder in your project and replace its app.js with this public/app.js.
4. Keep the other project files (index.html, styles.css, package.json, supabase.sql) unchanged.
5. Add OPENAI_API_KEY, OPENAI_MODEL, SUPABASE_URL, and SUPABASE_ANON_KEY as private environment variables on your hosting service.
6. In public/app.js, fill in SUPABASE_URL and SUPABASE_ANON_KEY where the placeholders appear. The Supabase anon/public key is intended for browser use when Row Level Security is enabled. Never put the Supabase service_role key there.

The files have not been deployed or tested against your own Supabase/OpenAI accounts. Your project must have its dependencies installed and the Supabase SQL setup completed.
